package org.selenium.pom.Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.selenium.pom.factory.DriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;


// This class start and quit the driver and has two objects (protected)
// driver who is a new object of WebDriver
// wait who is a new object of WebDriverWait
// these objects are instanced from the (DriverManager class)

public class BaseTest {

    // Access modifiers: PROTECTED
    // only the classes what are extends in BaseTest can use them
    protected WebDriver driver;
    protected WebDriverWait wait;


    //Instance the class(DriverManager()) and the method (initializeDriver()):
    @BeforeMethod
    public void startDriver(){
        driver = new DriverManager().initializeDriver();
    }

    // Once the automation has ended, the driver will close all:
    @AfterMethod
    public void tearDownDriver(){
        driver.quit();
    }
}
