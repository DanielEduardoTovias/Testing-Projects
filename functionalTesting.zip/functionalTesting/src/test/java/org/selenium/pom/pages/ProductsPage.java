package org.selenium.pom.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.selenium.pom.Base.BasePage;

public class ProductsPage extends BasePage {

    //private final By SearchingProducts = By.cssSelector("li[id='menu-item-1227'] a[class='menu-link']");
    private final By SearchingProducts = By.xpath("//li[@id='menu-item-1227']//a[@class='menu-link'][normalize-space()='Store']");
    public ProductsPage(WebDriver driver) {
        super(driver);
    }
    public ProductsPage load(){
        loadUrl("/");
        return this;
    }
    //TS2: this method do click by go to the store page from the home page:
    public ProductsPage clickSearchProducts(){
        driver.findElement(SearchingProducts).click();
        return new ProductsPage(driver);

    }
    /*public ProductsPage load(){
        return this;
    }*/


}

