package org.selenium.pom.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.selenium.pom.Base.BasePage;

public class SearchingProductsPage extends BasePage {

    //TS2: SearchingProductsPage definitions:
    // 1
    private final By waitForAddProduct = By.cssSelector("a[aria-label='Add “Blue Shoes” to your cart']");
    // 2
    private final By writeFldSearch = By.cssSelector("#woocommerce-product-search-field-0");
    // 3
    private final By clickSearchBtn = By.cssSelector("button[value='Search']");
    // 4
    private final By clickProduct = By.cssSelector("a:nth-child(1) > h2:nth-child(1)");




    // Constructor:
    public SearchingProductsPage(WebDriver driver) {
        super(driver);
    }

    //1
    public void waitingByAddProduct(){
        WebDriverWait wait = new WebDriverWait(driver,30);
        jsScrolling(600);
        wait.until(ExpectedConditions.presenceOfElementLocated(waitForAddProduct));
    }

    //2
    private By getWriteFldSearch(String nameProduct) {
        return By.cssSelector("#woocommerce-product-search-field-0");
    }

    public void cleanWriteProduct(String nameProduct) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver,30);
        jsScrolling(-600);
        wait.until(ExpectedConditions.presenceOfElementLocated(writeFldSearch)).clear();
        driver.findElement(writeFldSearch).sendKeys(nameProduct);
    }

    //3
    public void clickToSearchBtn(){
        driver.findElement(clickSearchBtn).click();
    }

    //4
    public void clickToProduct(){
        jsScrolling(700);
        driver.findElement(clickProduct).click();
    }


    // ----------------------
    // This method is use by the scroll-down: (x,y), scroll-up: (x,-y)

    private void jsScrolling(int pixel){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, "+pixel+")");
    }
}