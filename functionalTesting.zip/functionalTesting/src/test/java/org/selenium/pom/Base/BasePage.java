package org.selenium.pom.Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

    protected WebDriver driver;

    public BasePage(WebDriver driver){
        this.driver = driver;
    }

    // this method is by load de Url than will be use in the automation
    // and has how argument ("/") the next page what we go (endPoint):
    public void loadUrl(String endPoint){
        driver.get("https://askomdch.com" + endPoint);
    }
}

