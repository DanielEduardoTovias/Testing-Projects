package org.selenium.pom.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.selenium.pom.Base.BasePage;

public class HomePage  extends BasePage {

    //TS1 Register definition:
    private final By AccountButton = By.cssSelector("li[id='menu-item-1237'] a[class='menu-link']");

    public HomePage(WebDriver driver){
        super(driver);
    }

    public HomePage load(){
        loadUrl("/");
        return this;
    }

    //TS1: this method do click by go to the account page from the home page:
    public AccountPage clickAccountButton(){
        driver.findElement(AccountButton).click();
        return new AccountPage(driver);

    }
}
