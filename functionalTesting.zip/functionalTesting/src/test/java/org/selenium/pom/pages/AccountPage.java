package org.selenium.pom.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.selenium.pom.Base.BasePage;

public class AccountPage extends BasePage {
    //TS1: Register definitions:
    private final By searchFldUsername = By.cssSelector("#reg_username");
    private final By searchFldEmail = By.cssSelector("#reg_email");
    private final By SearchFldPassword = By.cssSelector("#reg_password");
    private final By searchFldButton = By.cssSelector("button[value='Register']");
    private final By waitingForElement =By.cssSelector(".has-text-align-center");


    // Constructor:
    public AccountPage(WebDriver driver) {
        super(driver);
    }

    //TS1: Register methods:
    // ----- We´re going to handle the UI´s element dinamically in both TS´s -----

    //userName:
    private By getSearchFldUsername(String userName){
        return By.cssSelector("#reg_username");
    }
    public void writeFldUsername(String userName){
        driver.findElement(searchFldUsername).clear();
        driver.findElement(searchFldUsername).sendKeys(userName);

    }

    //email:
    private By getSearchFldEmail(String email){
        return By.cssSelector("#reg_email");
    }
    public void writeFldEmail(String email){
        driver.findElement(searchFldEmail).clear();
        driver.findElement(searchFldEmail).sendKeys(email);
    }
    //password:
    private By getSearchFldPassword(String password){
        return By.cssSelector("#reg_password");
    }

    public void writeFldPassword(String password){
        //Clear the fields before of write the information:
        driver.findElement(SearchFldPassword).clear();
        driver.findElement(SearchFldPassword).sendKeys(password);
    }

    public void clickBtnRegister(){
        driver.findElement(searchFldButton).click();
    }

    public void waitingFor(){
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.presenceOfElementLocated(waitingForElement));
    }
}




