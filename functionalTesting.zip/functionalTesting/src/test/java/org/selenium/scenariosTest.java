package org.selenium;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.selenium.pom.Base.BaseTest;
import org.selenium.pom.pages.AccountPage;
import org.selenium.pom.pages.HomePage;
import org.selenium.pom.pages.ProductsPage;
import org.selenium.pom.pages.SearchingProductsPage;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;


public class scenariosTest extends BaseTest {

    @Test
    public void registerAndLoginTest() throws InterruptedException {
        // ------ chromedriver is in environments variables -----
        // check the version of your Google browser and download the version of chromedriver required
        //check the next page by download the version of chromedriver:
        //  https://chromedriver.chromium.org/downloads

        //TS1:
        //Instance of the method clickAccountButton() from HomePage() class:
        HomePage homePage = new HomePage(driver).load();
        //Fluent Interface
        homePage.clickAccountButton();
        AccountPage accountPage = new AccountPage(driver);
        accountPage.writeFldUsername("dinamically");
        accountPage.writeFldEmail("dinamically@gmail.com");
        accountPage.writeFldPassword("DINAMICALLY");
        accountPage.clickBtnRegister();
        accountPage.waitingFor();

    }

    //TS2:
    @Test
    public void searchProductsTest() throws InterruptedException {
        //Switch to go to StorePage: instance of the method clickSearchProducts() from ProductPage() class:
        ProductsPage productsPage = new ProductsPage(driver).load();

        productsPage.clickSearchProducts();
        SearchingProductsPage searchingProductsPage = new SearchingProductsPage(driver);
        searchingProductsPage.waitingByAddProduct();
        searchingProductsPage.cleanWriteProduct("green tshirt");
        searchingProductsPage.clickToSearchBtn();
        searchingProductsPage.clickToProduct();
    }
}
